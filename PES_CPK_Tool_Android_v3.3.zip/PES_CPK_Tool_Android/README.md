# PES CPK Tool Android v3.0

本版本重点针对 1GB+ PES/OBB CPK 解包速度做优化。解包优先直接通过 Android SAF 的可寻址文件描述符读取源 CPK，不再先把整个 1.3GB 文件复制进应用缓存；对未压缩条目优先使用 FileChannel 直传，减少 Java 缓冲区拷贝。

同时保留并强化 v2.1 的完整文件统计、错误不静默丢失、`.nomedia` 媒体库隔离、完整路径和 TOC 偏移处理。若当前文件提供商不支持随机读取，会自动回退到兼容缓存模式。

注意：目标目录仍使用 Android Storage Access Framework。对于包含数万小文件的 CPK，创建大量文件本身仍可能受文件提供商速度限制。

# PES CPK Tool — Android

Android Studio project that reimplements the useful PES CPK workflow of the supplied Windows tool without depending on `CpkMaker.DLL` / .NET Framework.

## Included
- Select `.cpk` with Android Storage Access Framework and extract all files.
- Select a folder and build a CPK.
- PES/CRIWARE CPK Mode 1 (TOC) parser and builder.
- `@UTF` table parser/builder with big-endian fields.
- CRILAYLA decompression and optional compression.
- Configurable alignment; default 1024 bytes to mirror the supplied `settings.ini`.
- Progress log and file counts.

## Important compatibility note
The supplied Windows app is a WinForms .NET launcher around `CpkMaker.DLL` from CRI Middleware. That DLL is a 32-bit Windows binary, so it cannot simply be copied into an Android APK. This project reimplements the portable CPK/UTF/CRILAYLA parts instead.

It aims for **PES2021-compatible CPKs**, not byte-for-byte reproduction of every CpkMaker.dll output. CRC metadata, random padding, and unusual CPK modes are not guaranteed to match the original binary exactly.

## Build
Open this folder with Android Studio and let Gradle sync. Then run `app` on an Android 8.0+ device.

A prebuilt APK is not included because the current build environment does not contain the Android SDK/NDK toolchain needed to produce and device-test an APK.


## v3.1 changes
- Fix packing crash caused by unsafe CRILAYLA compression buffer underflow.
- Compression is off by default for faster/safe repacking.
- If experimental compression is enabled and compression fails, the file falls back to raw storage instead of aborting the whole CPK build.

## v3.2 极速封装更新
- 封装 raw 模式不再把 SAF 输入目录复制到 App 缓存。
- 生成 CPK 时直接从用户选择的目录流式读取并直接写入最终 CPK 输出 URI。
- 不再把临时 CPK 再复制一次到目标文件。
- 将 TOC 构建从旧版重复构建三次优化为探测一次 + 最终一次。
- 大量文件时将“准备/封装”UI 回调降到每 1000 个文件一次，减少主线程更新开销。
- CRILAYLA 实验压缩限制在 64 MiB 以内，避免大文件压缩造成过高内存占用；压缩失败自动回退原文件。
- 保留 `.nomedia`、完整文件统计、删除文件后仍可重新封装等功能。
