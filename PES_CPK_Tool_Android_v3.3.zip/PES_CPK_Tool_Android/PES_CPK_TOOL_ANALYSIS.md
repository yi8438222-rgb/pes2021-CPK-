# PES CPK Tool BY STPN_17 — analysis and Android port notes

## 1. Supplied Windows package
The uploaded archive is a ZIP containing one RAR. The RAR contains:

- `PES CPK Tool.exe` — 42,496 bytes, PE32 GUI, .NET/Mono assembly.
- `CpkMaker.DLL` — 661,504 bytes, PE32 i386 DLL.
- `readme.txt`
- `settings.ini`

The EXE strings identify a WinForms UI, `PES CPK TOOL`, drag-and-drop input, extraction/build commands, logging, progress and an update checker.

The readme states that the program needs .NET Framework 4.6 and credits CRI Middleware's `CpkMaker.dll`.

## 2. Supplied settings.ini

```ini
[cfg]
align.size = 1024
try.compress = 1
enable.crc = 1
mask.dir = 1
rand.padding = 1
base.dir = "write something here or leave empty"
auto.check.update = 0
```

The Android port keeps the most important user-facing knobs: alignment, CRILAYLA compression and padding behavior. CRC is exposed as a reserved compatibility setting because reproducing every byte of CRI's original CRC handling is not the same thing as merely calculating a generic CRC32.

## 3. Why the original DLL cannot simply be ported
`CpkMaker.DLL` is a Windows PE32/i386 binary and imports the Windows/C runtime stack (`USER32`, `KERNEL32`, `MSVCP100`, `MSVCR100`) in addition to the managed-runtime boundary. Android cannot load that Windows DLL as an ordinary application library.

Therefore the Android version does **not** bundle or execute the original `CpkMaker.DLL`. It reimplements the portable archive logic in Java:

1. CPK chunk/header parsing.
2. CRI `@UTF` table parsing/building.
3. CPK Mode 1 (TOC) extraction/building.
4. CRILAYLA decompression and optional compression.
5. Android Storage Access Framework file/folder selection.

## 4. CPK behavior implemented

### Extraction
- Reads the 0x800-byte CPK header.
- Parses the `CpkHeader` `@UTF` table.
- Reads the `TOC ` chunk.
- Uses `DirName`, `FileName`, `FileOffset`, `FileSize`, `ExtractSize`, `ID`.
- Detects CRILAYLA by the `CRILAYLA` signature and restores the original file.
- Writes the directory tree to a user-selected Android folder.

### Building
- Creates CPK Mode 1 (`TOC `) archives.
- Uses 1024-byte alignment by default to mirror the supplied configuration.
- Sorts paths with the same underscore-after-tilde compatibility rule used by the reference implementation examined during migration.
- Writes `CPK `, `TOC ` and `ETOC` chunks.
- Uses CRILAYLA only when the compressed data is actually smaller than the source.
- Preserves the `(c)CRI` marker at the end of the 0x800-byte CPK header block.

## 5. Known compatibility limits
This is intended to produce **PES2021-compatible** CPKs, not to reproduce every byte emitted by the original CRI CpkMaker implementation.

Not guaranteed to be bit-identical:

- CRI CpkMaker's exact CRC metadata behavior.
- Every `mask.dir` nuance.
- Every random-padding convention.
- ITOC-only and other unusual CPK modes for building.
- Exact original ETOC/header metadata for every CRI toolchain generation.

The current reader focuses on TOC-mode archives, which is the most useful path for the PES2021 CPK workflow. An archive that is ITOC-only is rejected with a clear message instead of silently producing a wrong extraction.

## 6. Android file-handling architecture
Android's scoped-storage rules mean the app uses the Storage Access Framework rather than assuming direct filesystem paths. The current implementation stages selected files/folders under the app cache area, runs the CPK core there, and then writes the result back to the user-selected document/folder.

This is simple and reliable, but very large PES assets can temporarily require substantial free storage. A later optimization can switch the large-file path to seekable `ParcelFileDescriptor`/`FileChannel` I/O to reduce temporary duplication.

## 7. Verification performed in this environment
The pure-Java CPK core was compiled with Java 21 and tested with a synthetic two-file archive:

- Pack directory → CPK Mode 1.
- Inspect header/mode/alignment/file count.
- Extract CPK.
- Verify extracted bytes match the originals.
- Exercise CRILAYLA compression/decompression on a repeated binary sample.

Result: `PASS: CPK build/inspect/extract + CRILAYLA roundtrip`.

The full Android APK was not produced here because this execution environment does not contain the Android SDK/NDK/Gradle toolchain required for a device-tested APK build.
