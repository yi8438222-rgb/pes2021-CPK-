# PES CPK Tool Android v2

This version focuses on CPK extraction reliability and speed.

## Main fixes

1. Raw CPK entries are streamed directly from the copied CPK to the selected Android folder instead of first writing every extracted file to an app cache folder and then copying everything again.
2. CPK TOC file offsets use the CRIWARE reference baseline rule instead of assuming every archive has exactly the same layout.
3. Directory handles are cached, reducing repeated SAF directory operations.
4. A failed file no longer silently disappears: extraction continues and reports the exact failed path and error.
5. The UI reports successful/failed file counts.
6. CPK inspection previews 100 entries instead of 40 and clearly states that it is only a preview.
7. AndroidX is enabled in gradle.properties.

## Important compatibility note

This build still implements TOC-mode CPK extraction/packing. ITOC/GTOC-only archives require a later compatibility pass.


## v2.1 media-library fix
- Extract root creates `.nomedia` so extracted image/audio/video assets are not indexed by Android media gallery.
- Packing skips `.nomedia` automatically.
