package com.stpn17.pescpktool.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Minimal CRIWARE @UTF table implementation used by CPK. */
public final class UtfTable {
    public enum Type { UCHAR, CHAR, USHORT, SHORT, UINT, INT, ULONG, LONG, FLOAT, DOUBLE, STRING, BYTES }
    public enum Storage { CONSTANT(0x10), PER_ROW(0x30), DATA(0x50); final int flag; Storage(int f){flag=f;} }
    public static final class Column {
        public final String name; public final Type type; public final Storage storage; public Object constant;
        public Column(String name, Type type, Storage storage, Object constant){this.name=name;this.type=type;this.storage=storage;this.constant=constant;}
    }

    public String name = "";
    public final List<Column> columns = new ArrayList<>();
    public final List<Map<String,Object>> rows = new ArrayList<>();

    public boolean has(String col){ for(Column c: columns) if(c.name.equals(col)) return true; return false; }
    public Object get(int row,String col){ return rows.get(row).get(col); }
    public <T> T getAs(int row,String col,Class<T> type){ return type.cast(get(row,col)); }

    private static int be16(byte[] b,int p){return ((b[p]&255)<<8)|(b[p+1]&255);}
    private static long be32(byte[] b,int p){return ((long)(b[p]&255)<<24)|((long)(b[p+1]&255)<<16)|((long)(b[p+2]&255)<<8)|(b[p+3]&255L);}
    private static long be64(byte[] b,int p){return (be32(b,p)<<32) | (be32(b,p+4)&0xffffffffL);}
    private static void put16(ByteArrayOutputStream o,int v){o.write((v>>>8)&255);o.write(v&255);}
    private static void put32(ByteArrayOutputStream o,long v){o.write((int)(v>>>24)&255);o.write((int)(v>>>16)&255);o.write((int)(v>>>8)&255);o.write((int)v&255);}
    private static void put64(ByteArrayOutputStream o,long v){put32(o,v>>>32);put32(o,v);}

    private static int typeSize(Type t){ return switch(t){
        case UCHAR,CHAR->1; case USHORT,SHORT->2; case UINT,INT,FLOAT,STRING->4; case ULONG,LONG,DOUBLE,BYTES->8;}; }

    private static Object defaultValue(Type t){ return switch(t){
        case UCHAR->(byte)0; case CHAR->(byte)0; case USHORT->0; case SHORT->0; case UINT->0L; case INT->0; case ULONG->0L; case LONG->0L;
        case FLOAT->0f; case DOUBLE->0d; case STRING->"<NULL>"; case BYTES->new byte[0];}; }

    private static String cstr(byte[] data,int start,int end){
        if(start<0 || start>=end) return "";
        int p=start; while(p<end && data[p]!=0)p++;
        return new String(data,start,p-start, StandardCharsets.UTF_8);
    }

    private static Object readValue(byte[] data,int p,Type t,byte[] full,int strStart,int strEnd,int blobStart,int blobEnd){
        return switch(t){
            case UCHAR,CHAR -> data[p];
            case USHORT,SHORT -> be16(data,p);
            case UINT,INT -> be32(data,p);
            case ULONG,LONG -> be64(data,p);
            case FLOAT -> Float.intBitsToFloat((int)be32(data,p));
            case DOUBLE -> Double.longBitsToDouble(be64(data,p));
            case STRING -> { long off=be32(data,p); yield off<(strEnd-strStart)?cstr(full,strStart+(int)off,strEnd):""; }
            case BYTES -> { long off=be32(data,p), len=be32(data,p+4); if(off+len>(blobEnd-blobStart)) yield new byte[0]; yield Arrays.copyOfRange(full,blobStart+(int)off,blobStart+(int)(off+len)); }
        };
    }

    private static byte[] decrypt(byte[] src){
        byte[] out=src.clone(); long m=0x655fL,t=0x4115L;
        for(int i=0;i<out.length;i++){out[i]^=(byte)(m&255);m=(m*t)&0xffffffffL;}
        return out;
    }

    public static UtfTable parse(byte[] input){
        if(input.length<32) throw new IllegalArgumentException("UTF table too small");
        byte[] data=input;
        if((input[0]&255)==0x1f && (input[1]&255)==0x9e && (input[2]&255)==0xf3 && (input[3]&255)==0xf5) data=decrypt(input);
        if(!(data[0]=='@'&&data[1]=='U'&&data[2]=='T'&&data[3]=='F')) throw new IllegalArgumentException("Invalid @UTF table");
        long tableSize=be32(data,4), rowsOffset=be32(data,8), stringOffset=be32(data,12), dataOffset=be32(data,16), nameOffset=be32(data,20);
        int cols=be16(data,24), rowLen=be16(data,26); long rowCount=be32(data,28);
        long total=8+tableSize; if(total>data.length) total=data.length;
        int base=8; int strStart=(int)(base+stringOffset), strEnd=(int)(base+dataOffset), blobStart=strEnd, blobEnd=(int)(base+tableSize);
        UtfTable table=new UtfTable();
        table.name=cstr(data,strStart+(int)nameOffset,strEnd);
        int p=32;
        for(int i=0;i<cols;i++){
            int flag=data[p++]&255; Storage storage=switch(flag&0xf0){case 0x10->Storage.CONSTANT;case 0x30->Storage.PER_ROW;case 0x50->Storage.DATA;default->throw new IllegalArgumentException("Unsupported UTF storage 0x"+Integer.toHexString(flag&0xf0));};
            Type type=switch(flag&0x0f){case 0->Type.UCHAR;case 1->Type.CHAR;case 2->Type.USHORT;case 3->Type.SHORT;case 4->Type.UINT;case 5->Type.INT;case 6->Type.ULONG;case 7->Type.LONG;case 8->Type.FLOAT;case 9->Type.DOUBLE;case 10->Type.STRING;case 11->Type.BYTES;default->throw new IllegalArgumentException("Unknown UTF type");};
            int no=(int)be32(data,p);p+=4; String cn=cstr(data,strStart+no,strEnd); Object cv=defaultValue(type);
            if(storage==Storage.PER_ROW){cv=readValue(data,p,type,data,strStart,strEnd,blobStart,blobEnd);p+=typeSize(type);} 
            table.columns.add(new Column(cn,type,storage,cv));
        }
        int rowBase=base+(int)rowsOffset;
        for(int r=0;r<rowCount;r++){
            Map<String,Object> row=new LinkedHashMap<>(); int rp=rowBase+r*rowLen;
            for(Column c:table.columns){Object v=c.storage==Storage.DATA?readValue(data,rp,c.type,data,strStart,strEnd,blobStart,blobEnd):c.constant; row.put(c.name,v); if(c.storage==Storage.DATA) rp+=typeSize(c.type);} table.rows.add(row);
        }
        return table;
    }

    public byte[] build(){
        List<byte[]> none=List.of();
        ByteArrayOutputStream strings=new ByteArrayOutputStream(); Map<String,Integer> soff=new LinkedHashMap<>();
        java.util.function.Function<String,Integer> addString = s -> {
            if(s==null)s=""; Integer old=soff.get(s); if(old!=null)return old; int off=strings.size(); soff.put(s,off); byte[] b=s.getBytes(StandardCharsets.UTF_8); strings.writeBytes(b); strings.write(0); return off;
        };
        addString.apply("<NULL>"); int tableNameOff=addString.apply(name);
        for(Column c:columns)addString.apply(c.name);
        for(Column c:columns) if(c.type==Type.STRING && c.storage!=Storage.CONSTANT){String s=String.valueOf(c.constant); if(!s.isEmpty())addString.apply(s);}
        if(name.equals("CpkTocInfo")||name.equals("CpkEtocInfo"))addString.apply("");
        for(Map<String,Object> row:rows) for(Column c:columns) if(c.storage==Storage.DATA&&c.type==Type.STRING){String s=String.valueOf(row.getOrDefault(c.name,c.constant)); if(!s.isEmpty())addString.apply(s);}

        ByteArrayOutputStream colData=new ByteArrayOutputStream(), rowData=new ByteArrayOutputStream(), blob=new ByteArrayOutputStream();
        int rowLen=0;
        for(Column c:columns){colData.write(c.storage.flag|typeCode(c.type));put32(colData,soff.getOrDefault(c.name,0)); if(c.storage==Storage.PER_ROW){writeValue(colData,c.constant,c.type,soff,blob);} else if(c.storage==Storage.DATA) rowLen+=typeSize(c.type);}
        for(Map<String,Object> row:rows) for(Column c:columns) if(c.storage==Storage.DATA) writeValue(rowData,row.getOrDefault(c.name,c.constant),c.type,soff,blob);
        if(name.equals("CpkHeader")) for(int i=0;i<7;i++)strings.write(0);
        else if(name.equals("CpkTocInfo"))for(int i=0;i<4;i++)strings.write(0);
        else if(name.equals("CpkEtocInfo"))for(int i=0;i<6;i++)strings.write(0);
        int rowsOff=24+colData.size(); int stringOff=rowsOff+rowData.size(); int dataOff=stringOff+strings.size(); int tableSize=dataOff+blob.size();
        ByteArrayOutputStream out=new ByteArrayOutputStream(8+tableSize); out.writeBytes(new byte[]{'@','U','T','F'});put32(out,tableSize);put32(out,rowsOff);put32(out,stringOff);put32(out,dataOff);put32(out,tableNameOff);put16(out,columns.size());put16(out,rowLen);put32(out,rows.size());out.writeBytes(colData.toByteArray());out.writeBytes(rowData.toByteArray());out.writeBytes(strings.toByteArray());out.writeBytes(blob.toByteArray());return out.toByteArray();
    }

    private static int typeCode(Type t){return switch(t){case UCHAR->0;case CHAR->1;case USHORT->2;case SHORT->3;case UINT->4;case INT->5;case ULONG->6;case LONG->7;case FLOAT->8;case DOUBLE->9;case STRING->10;case BYTES->11;};}
    private static void writeValue(ByteArrayOutputStream out,Object value,Type t,Map<String,Integer> soff,ByteArrayOutputStream blob){
        if(value==null) value=defaultValue(t);
        switch(t){
            case UCHAR,CHAR -> out.write(((Number)value).byteValue()&255);
            case USHORT,SHORT -> put16(out,((Number)value).intValue());
            case UINT,INT -> put32(out,((Number)value).longValue());
            case ULONG,LONG -> put64(out,((Number)value).longValue());
            case FLOAT -> put32(out,Float.floatToRawIntBits(((Number)value).floatValue())&0xffffffffL);
            case DOUBLE -> put64(out,Double.doubleToRawLongBits(((Number)value).doubleValue()));
            case STRING -> put32(out,soff.getOrDefault(String.valueOf(value),0));
            case BYTES -> {byte[] b=(byte[])value; int off=blob.size();blob.writeBytes(b);put32(out,off);put32(out,b.length);} }
    }
}
