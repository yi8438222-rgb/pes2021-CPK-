package com.stpn17.pescpktool.core;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** CRILAYLA decoder/encoder used by CRIWARE CPKs. */
public final class Crilayla {
    private Crilayla() {}
    public static boolean isCompressed(byte[] d){ return d.length>=16 && d[0]=='C'&&d[1]=='R'&&d[2]=='I'&&d[3]=='L'&&d[4]=='A'&&d[5]=='Y'&&d[6]=='L'&&d[7]=='A'; }
    private static long le32(byte[] b,int p){return (b[p]&255L)|((b[p+1]&255L)<<8)|((b[p+2]&255L)<<16)|((b[p+3]&255L)<<24);}
    private static void putLe32(byte[] b,int p,long v){b[p]=(byte)v;b[p+1]=(byte)(v>>>8);b[p+2]=(byte)(v>>>16);b[p+3]=(byte)(v>>>24);}

    private static final class BitReader {
        final byte[] b; int pos; int bits, data;
        BitReader(byte[] b){this.b=b;this.pos=b.length-1;}
        int get(int n){
            while(bits<n){int need=((24-bits)>>>3)+1;bits+=need*8;while(need-->0)data=(data<<8)|(b[pos--]&255);}
            int v=data>>>(bits-n);bits-=n;return v&((1<<n)-1);
        }
    }

    public static byte[] decompress(byte[] d){
        if(!isCompressed(d)||d.length<272) throw new IllegalArgumentException("Invalid CRILAYLA stream");
        int unc=(int)le32(d,8), comp=(int)le32(d,12); if(16L+comp+256>d.length)throw new IllegalArgumentException("Bad CRILAYLA size");
        byte[] out=new byte[256+unc];System.arraycopy(d,16+comp,out,0,256);BitReader br=new BitReader(Arrays.copyOfRange(d,16,16+comp));
        int dst=out.length-1,start=256;while(dst>=start){
            if(br.get(1)==0){out[dst--]=(byte)br.get(8);continue;}
            int off=br.get(13),len=br.get(2);if(len==3){len+=br.get(3);if(len==10){len+=br.get(5);if(len==41){int x;do{x=br.get(8);len+=x;}while(x==255);}}}len+=3;int src=dst+off+3;while(len-->0&&dst>=start)out[dst--]=out[src--];
        }return out;
    }

    /** Compression is intentionally conservative: original data is returned when the compressed result is not smaller. */
    public static byte[] compress(byte[] data){
        if(data.length<256)return data;
        int n=data.length-1,m=data.length-1,T=0;long d=0;byte[] tmp=new byte[data.length+0x110];
        while(n>=0x100){int j=Math.min(data.length,n+3+0x2000),p=0,q=0;for(int i=n+3;i<j;i++){int k=0;while(k<=n-0x100&&data[n-k]==data[i-k])k++;if(k>p){q=i-n-3;p=k;}}
            if(p<3){d=(d<<9)|(data[n--]&255);T+=9;}else{d=(((d<<1)|1)<<13)|q;T+=14;n-=p;if(p<6){d=(d<<2)|(p-3);T+=2;}else if(p<13){d=(((d<<2)|3)<<3)|(p-6);T+=5;}else if(p<44){d=(((d<<5)|0x1f)<<5)|(p-13);T+=10;}else{d=(d<<10)|0x3ff;T+=10;p-=44;while(true){while(T>=8){tmp[m--]=(byte)((d>>>(T-8))&255);T-=8;d&=(1L<<T)-1;}if(p<255)break;d=(d<<8)|0xff;T+=8;p-=255;}d=(d<<8)|p;T+=8;}}
            while(T>=8){tmp[m--]=(byte)((d>>>(T-8))&255);T-=8;d&=(1L<<T)-1;}
        }
        if(T!=0)tmp[m--]=(byte)(d<<(8-T));tmp[m--]=0;tmp[m]=0;while(((data.length-m)&3)!=0)tmp[m--]=0;int comp=data.length-m;byte[] out=new byte[16+comp+256];System.arraycopy("CRILAYLA".getBytes(),0,out,0,8);putLe32(out,8,data.length-256);putLe32(out,12,comp);System.arraycopy(tmp,m,out,16,comp);System.arraycopy(data,0,out,16+comp,256);return out;
    }
}
