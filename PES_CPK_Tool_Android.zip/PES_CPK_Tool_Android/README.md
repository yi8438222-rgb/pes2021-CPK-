# PES CPK Tool — Android

Android Studio project that reimplements the useful PES CPK workflow of the supplied Windows tool without depending on `CpkMaker.DLL` / .NET Framework.

## Included
- Select `.cpk` with Android Storage Access Framework and extract all files.
- Select a folder and build a CPK.
- PES/CRIWARE CPK Mode 1 (TOC) parser and builder.
- `@UTF` table parser/builder with big-endian fields.
- CRILAYLA decompression and optional compression.
- Configurable alignment; default 1024 bytes to mirror the supplied `settings.ini`.
- Progress log and file counts.

## Important compatibility note
The supplied Windows app is a WinForms .NET launcher around `CpkMaker.DLL` from CRI Middleware. That DLL is a 32-bit Windows binary, so it cannot simply be copied into an Android APK. This project reimplements the portable CPK/UTF/CRILAYLA parts instead.

It aims for **PES2021-compatible CPKs**, not byte-for-byte reproduction of every CpkMaker.dll output. CRC metadata, random padding, and unusual CPK modes are not guaranteed to match the original binary exactly.

## Build
Open this folder with Android Studio and let Gradle sync. Then run `app` on an Android 8.0+ device.

A prebuilt APK is not included because the current build environment does not contain the Android SDK/NDK toolchain needed to produce and device-test an APK.
