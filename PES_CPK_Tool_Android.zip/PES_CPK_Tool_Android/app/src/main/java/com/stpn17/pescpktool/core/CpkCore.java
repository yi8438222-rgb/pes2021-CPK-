package com.stpn17.pescpktool.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;

/** PES/CRIWARE CPK reader and Mode-1 builder. */
public final class CpkCore {
    public interface Listener { void onProgress(String message, int current, int total); }
    public static final Listener NOOP=(m,c,t)->{};
    public record Options(int alignment, boolean tryCompress, boolean randomPadding, boolean enableCrc) {}
    public record Entry(String dir,String name,long offset,long fileSize,long extractSize,long id){
        public String path(){return dir==null||dir.isEmpty()?name:dir+"/"+name;}
        public boolean compressed(){return extractSize>fileSize;}
    }
    public record Info(int mode,int alignment,long fileCount,long contentOffset,long contentSize,String version,List<Entry> entries){}

    private CpkCore(){}
    private static long le32(byte[] b,int p){return (b[p]&255L)|((b[p+1]&255L)<<8)|((b[p+2]&255L)<<16)|((b[p+3]&255L)<<24);}
    private static void putLe32(OutputStream o,long v)throws IOException{o.write((int)v&255);o.write((int)(v>>>8)&255);o.write((int)(v>>>16)&255);o.write((int)(v>>>24)&255);}
    private static void pad(OutputStream out,long n,boolean random)throws IOException{byte[] b=new byte[8192];java.util.Random r=random?new java.util.Random(0x17C0FFEE):null;while(n>0){int k=(int)Math.min(n,b.length);if(r!=null)r.nextBytes(b);else Arrays.fill(b,(byte)0);out.write(b,0,k);n-=k;}}
    private static long align(long v,long a){return (v+a-1)/a*a;}
    private static long num2(Object x){return x instanceof Number?((Number)x).longValue():Long.parseLong(String.valueOf(x));}

    public static Info inspect(File cpk)throws Exception{
        try(RandomAccessFile raf=new RandomAccessFile(cpk,"r")){
            byte[] hdr=new byte[0x800];raf.readFully(hdr);checkMagic(hdr,"CPK ");UtfTable t=UtfTable.parse(Arrays.copyOfRange(hdr,16,hdr.length));
            long tocOff=getLong(t,"TocOffset",0),tocSize=getLong(t,"TocSize",0),contentOff=getLong(t,"ContentOffset",0),contentSize=getLong(t,"ContentSize",0);int align=(int)getLong(t,"Align",0x800);int mode=(int)getLong(t,"CpkMode",1);String ver=getString(t,"Tvers","");
            List<Entry> entries=new ArrayList<>();
            if(tocOff>0&&tocSize>0){raf.seek(tocOff);byte[] toc=new byte[(int)tocSize];raf.readFully(toc);checkMagic(toc,"TOC ");UtfTable tt=UtfTable.parse(Arrays.copyOfRange(toc,16,toc.length));for(int i=0;i<tt.rows.size();i++){String d=getString(tt,i,"DirName","");String f=getString(tt,i,"FileName","");long fs=getLong(tt,i,"FileSize",0),xs=getLong(tt,i,"ExtractSize",fs),off=getLong(tt,i,"FileOffset",0),id=getLong(tt,i,"ID",i);entries.add(new Entry(d,f,off,fs,xs,id));}}
            else if(getLong(t,"ItocOffset",0)>0) throw new UnsupportedOperationException("This Android build currently reads TOC-mode CPKs only; this archive appears to use ITOC mode.");
            return new Info(mode,align,entries.size(),contentOff,contentSize,ver,Collections.unmodifiableList(entries));
        }
    }

    public static void extract(File cpk,File outDir,Listener listener)throws Exception{
        Info info=inspect(cpk);Files.createDirectories(outDir.toPath());try(RandomAccessFile raf=new RandomAccessFile(cpk,"r")){
            for(int i=0;i<info.entries.size();i++){
                Entry e=info.entries.get(i);Path out=outDir.toPath().resolve(e.path());Files.createDirectories(out.getParent());raf.seek(0x800L+e.offset);byte[] raw=readFully(raf,e.fileSize);byte[] data=Crilayla.isCompressed(raw)&&e.compressed()?Crilayla.decompress(raw):raw;Files.write(out,data);listener.onProgress("Extracted: "+e.path(),i+1,info.entries.size());
            }
        }
    }

    private static byte[] readFully(RandomAccessFile r,long size)throws IOException{if(size>Integer.MAX_VALUE)throw new IOException("Single CPK file too large for this build: "+size);byte[] b=new byte[(int)size];r.readFully(b);return b;}
    private static void checkMagic(byte[] b,String s)throws IOException{for(int i=0;i<4;i++)if(b[i]!=(byte)s.charAt(i))throw new IOException("Invalid CPK/TOC magic");}
    private static long getLong(UtfTable t,String c,long def){return t.has(c)&&!t.rows.isEmpty()?num2(t.get(0,c)):def;}
    private static String getString(UtfTable t,String c,String def){return t.has(c)&&!t.rows.isEmpty()?String.valueOf(t.get(0,c)):def;}
    private static long getLong(UtfTable t,int row,String c,long def){return t.has(c)?num2(t.get(row,c)):def;}
    private static String getString(UtfTable t,int row,String c,String def){return t.has(c)?String.valueOf(t.get(row,c)):def;}

    private static final class Fi {String archivePath,dir,name,source;long extractSize,fileSize,offset,id;File staged;}

    public static void pack(File inputDir,File output,Options opt,Listener listener)throws Exception{
        if(!inputDir.isDirectory())throw new IOException("Input is not a directory");Files.createDirectories(output.toPath().getParent()==null?output.toPath().toAbsolutePath().getParent():output.toPath().getParent());
        List<Fi> fs=new ArrayList<>();try(var walk=Files.walk(inputDir.toPath())){walk.filter(Files::isRegularFile).forEach(p->{Fi f=new Fi();f.source=p.toString();f.archivePath=inputDir.toPath().relativize(p).toString().replace(File.separatorChar,'/');fs.add(f);});}
        fs.sort(Comparator.comparing(a->sortKey(a.archivePath)));
        Path stage=Files.createTempDirectory("pes-cpk-stage-");
        try{
            for(int i=0;i<fs.size();i++){
                Fi f=fs.get(i);int last=f.archivePath.lastIndexOf('/');f.dir=last>=0?f.archivePath.substring(0,last):"";f.name=last>=0?f.archivePath.substring(last+1):f.archivePath;f.id=i;File src=new File(f.source);f.extractSize=src.length();
                if(opt.tryCompress && f.extractSize>=256){byte[] srcBytes=Files.readAllBytes(src.toPath());byte[] cmp=Crilayla.compress(srcBytes);if(cmp.length<srcBytes.length){f.fileSize=cmp.length;f.staged=stage.resolve(String.format(Locale.ROOT,"%06d.bin",i)).toFile();Files.write(f.staged.toPath(),cmp);}else{f.fileSize=f.extractSize;}}
                else f.fileSize=f.extractSize;
                listener.onProgress("Prepared: "+f.archivePath,i+1,fs.size());
            }
            // Build TOC twice because FileOffset depends on final padded TOC size.
            UtfTable toc=buildToc(fs,0);byte[] tocUtf=toc.build();long tocChunk=align(16L+tocUtf.length,opt.alignment);
            long off=tocChunk;for(Fi f:fs){f.offset=off;off+=align(f.fileSize,opt.alignment);}toc=buildToc(fs,tocChunk);tocUtf=toc.build();tocChunk=align(16L+tocUtf.length,opt.alignment);
            // Re-check offsets after final TOC build.
            off=tocChunk;for(Fi f:fs){f.offset=off;off+=align(f.fileSize,opt.alignment);}toc=buildToc(fs,tocChunk);tocUtf=toc.build();tocChunk=align(16L+tocUtf.length,opt.alignment);
            long contentSize=0;for(Fi f:fs)contentSize+=align(f.fileSize,opt.alignment);long contentOffset=0x800L+tocChunk;long etocOffset=contentOffset+contentSize;long totalData=0,packed=0;for(Fi f:fs){packed+=f.fileSize;totalData+=f.extractSize;}
            UtfTable header=buildHeader(fs.size(),opt.alignment,contentOffset,contentSize,tocUtf.length+16,etocOffset,packed,totalData);byte[] headerUtf=header.build();
            byte[] headerChunk=new byte[0x800];System.arraycopy(new byte[]{'C','P','K',' '},0,headerChunk,0,4);headerChunk[4]=(byte)0xff;
            putLe32At(headerChunk,8,headerUtf.length);System.arraycopy(headerUtf,0,headerChunk,16,Math.min(headerUtf.length,headerChunk.length-16));System.arraycopy("(c)CRI".getBytes(java.nio.charset.StandardCharsets.US_ASCII),0,headerChunk,0x800-6,6);
            byte[] tocChunkBytes=new byte[(int)tocChunk];System.arraycopy(new byte[]{'T','O','C',' '},0,tocChunkBytes,0,4);putLe32At(tocChunkBytes,4,0xff);putLe32At(tocChunkBytes,8,tocUtf.length);System.arraycopy(tocUtf,0,tocChunkBytes,16,tocUtf.length);
            UtfTable etoc=buildEtoc(fs.size());byte[] etocUtf=etoc.build();byte[] etocChunk=new byte[16+etocUtf.length];System.arraycopy(new byte[]{'E','T','O','C'},0,etocChunk,0,4);putLe32At(etocChunk,4,0xff);putLe32At(etocChunk,8,etocUtf.length);System.arraycopy(etocUtf,0,etocChunk,16,etocUtf.length);
            try(OutputStream out=new BufferedOutputStream(new FileOutputStream(output),1024*1024)){out.write(headerChunk);out.write(tocChunkBytes);for(int i=0;i<fs.size();i++){Fi f=fs.get(i);Path p=f.staged!=null?f.staged.toPath():Path.of(f.source);try(InputStream in=new BufferedInputStream(Files.newInputStream(p),1024*1024)){in.transferTo(out);}long pad=align(f.fileSize,opt.alignment)-f.fileSize;pad(out,pad,opt.randomPadding);listener.onProgress("Packed: "+f.archivePath,i+1,fs.size());}out.write(etocChunk);}
        }finally{try(var walk=Files.walk(stage)){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
    }

    private static String sortKey(String s){StringBuilder b=new StringBuilder(s.length());for(char c:s.toCharArray())b.append(c=='_'?'~':Character.toLowerCase(c));return b.toString();}
    private static int mode1Version(){return 1;}
    private static void putLe32At(byte[] b,int p,long v){b[p]=(byte)v;b[p+1]=(byte)(v>>>8);b[p+2]=(byte)(v>>>16);b[p+3]=(byte)(v>>>24);}

    private static UtfTable buildToc(List<Fi> fs,long ignored){UtfTable t=new UtfTable();t.name="CpkTocInfo";t.columns.add(new UtfTable.Column("DirName",UtfTable.Type.STRING,UtfTable.Storage.DATA,""));t.columns.add(new UtfTable.Column("FileName",UtfTable.Type.STRING,UtfTable.Storage.DATA,""));t.columns.add(new UtfTable.Column("FileSize",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ExtractSize",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("FileOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ID",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("UserString",UtfTable.Type.STRING,UtfTable.Storage.CONSTANT,"<NULL>"));for(Fi f:fs){Map<String,Object> r=new LinkedHashMap<>();r.put("DirName",f.dir);r.put("FileName",f.name);r.put("FileSize",f.fileSize);r.put("ExtractSize",f.extractSize);r.put("FileOffset",f.offset);r.put("ID",f.id);t.rows.add(r);}return t;}

    private static UtfTable buildHeader(int files,int align,long contentOff,long contentSize,long tocSize,long etocOff,long packed,long extracted){UtfTable t=new UtfTable();t.name="CpkHeader";
        t.columns.add(new UtfTable.Column("UpdateDateTime",UtfTable.Type.ULONG,UtfTable.Storage.DATA,1L));t.columns.add(new UtfTable.Column("FileSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("ContentOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ContentSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TocOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TocSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TocCrc",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("EtocOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("EtocSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ItocOffset",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("ItocSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("ItocCrc",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("GtocOffset",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("GtocSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("GtocCrc",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("EnabledPackedSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("EnabledDataSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TotalDataSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Tocs",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Files",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("Groups",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("Attrs",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TotalFiles",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Directories",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Updates",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Version",UtfTable.Type.USHORT,UtfTable.Storage.DATA,7));t.columns.add(new UtfTable.Column("Revision",UtfTable.Type.USHORT,UtfTable.Storage.DATA,1));t.columns.add(new UtfTable.Column("Align",UtfTable.Type.USHORT,UtfTable.Storage.DATA,align));t.columns.add(new UtfTable.Column("Sorted",UtfTable.Type.USHORT,UtfTable.Storage.DATA,1));t.columns.add(new UtfTable.Column("EID",UtfTable.Type.USHORT,UtfTable.Storage.CONSTANT,0));t.columns.add(new UtfTable.Column("CpkMode",UtfTable.Type.UINT,UtfTable.Storage.DATA,1L));t.columns.add(new UtfTable.Column("Tvers",UtfTable.Type.STRING,UtfTable.Storage.DATA,"CPKMC2.30.07, DLL3.00.07"));t.columns.add(new UtfTable.Column("Comment",UtfTable.Type.STRING,UtfTable.Storage.CONSTANT,""));t.columns.add(new UtfTable.Column("Codec",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("DpkItoc",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));
        Map<String,Object> r=new LinkedHashMap<>();r.put("UpdateDateTime",1L);r.put("ContentOffset",contentOff);r.put("ContentSize",contentSize);r.put("TocOffset",0x800L);r.put("TocSize",tocSize);r.put("EtocOffset",etocOff);r.put("EtocSize",128L);r.put("EnabledPackedSize",packed+extracted);r.put("EnabledDataSize",packed+extracted);r.put("Files",(long)files);r.put("Groups",0L);r.put("Attrs",0L);r.put("Version",7);r.put("Revision",1);r.put("Align",align);r.put("Sorted",1);r.put("CpkMode",1L);r.put("Tvers","CPKMC2.30.07, DLL3.00.07");r.put("Codec",0L);r.put("DpkItoc",0L);t.rows.add(r);return t;}
    private static UtfTable buildEtoc(int files){UtfTable t=new UtfTable();t.name="CpkEtocInfo";t.columns.add(new UtfTable.Column("UpdateDateTime",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("LocalDir",UtfTable.Type.STRING,UtfTable.Storage.PER_ROW,""));for(int i=0;i<files;i++){Map<String,Object> r=new LinkedHashMap<>();r.put("UpdateDateTime",569143605520244480L);t.rows.add(r);}Map<String,Object> term=new LinkedHashMap<>();term.put("UpdateDateTime",0L);t.rows.add(term);return t;}
}
