package com.stpn17.pescpktool;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.*;

import androidx.documentfile.provider.DocumentFile;

import com.stpn17.pescpktool.core.CpkCore;

import java.io.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_CPK=10, PICK_EXTRACT_DIR=11, PICK_INPUT_DIR=12, CREATE_CPK=13, PICK_INSPECT=15;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private TextView status,log;
    private EditText alignEdit;
    private Switch compressSwitch, randomSwitch, crcSwitch;
    private Uri pendingCpk;
    private File tempRoot;

    @Override public void onCreate(Bundle b){super.onCreate(b); tempRoot=new File(getCacheDir(),"cpkwork");tempRoot.mkdirs();buildUi();}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(12));
        TextView title=new TextView(this);title.setText("PES CPK Tool Android v2.1");title.setTextSize(24);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=new TextView(this);sub.setText("高速解包 · 完整路径 · 进度/失败统计 · PES2021 / CRIWARE CPK");sub.setTextSize(14);root.addView(sub,new LinearLayout.LayoutParams(-1,-2));

        Button extract=new Button(this);extract.setText("选择 .CPK → 高速解包");extract.setOnClickListener(v->pickCpk());root.addView(extract,lp());
        Button pack=new Button(this);pack.setText("选择文件夹 → 封装 .CPK");pack.setOnClickListener(v->pickInputDir());root.addView(pack,lp());
        Button inspect=new Button(this);inspect.setText("检查 CPK 信息");inspect.setOnClickListener(v->pickCpkForInspect());root.addView(inspect,lp());

        TextView cfg=new TextView(this);cfg.setText("CPK Build Options");cfg.setTextSize(18);cfg.setPadding(0,dp(10),0,dp(4));root.addView(cfg);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);TextView a=new TextView(this);a.setText("Align: ");a.setGravity(16);row.addView(a,new LinearLayout.LayoutParams(-2,-2));alignEdit=new EditText(this);alignEdit.setInputType(2);alignEdit.setText("1024");row.addView(alignEdit,new LinearLayout.LayoutParams(dp(110),-2));root.addView(row);
        compressSwitch=new Switch(this);compressSwitch.setText("Try CRILAYLA compression");compressSwitch.setChecked(true);root.addView(compressSwitch);
        randomSwitch=new Switch(this);randomSwitch.setText("Random padding");randomSwitch.setChecked(true);root.addView(randomSwitch);
        crcSwitch=new Switch(this);crcSwitch.setText("Enable CRC metadata (compatibility flag)");crcSwitch.setChecked(true);root.addView(crcSwitch);

        status=new TextView(this);status.setText("状态：就绪");status.setPadding(0,dp(8),0,dp(8));root.addView(status);
        ScrollView sv=new ScrollView(this);log=new TextView(this);log.setTextSize(12);log.setTextIsSelectable(true);log.setPadding(dp(8),dp(8),dp(8),dp(8));sv.addView(log);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private LinearLayout.LayoutParams lp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(6);return p;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void pickCpk(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_CPK);}
    private void pickCpkForInspect(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_INSPECT);}
    private void pickInputDir(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);startActivityForResult(i,PICK_INPUT_DIR);}
    private void pickExtractDir(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);startActivityForResult(i,PICK_EXTRACT_DIR);}
    private void createCpk(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"rebuilt.cpk");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,CREATE_CPK);}

    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;
        if(req==PICK_CPK){pendingCpk=data.getData();pickExtractDir();}
        else if(req==PICK_EXTRACT_DIR){Uri out=data.getData();runExtract(pendingCpk,out);}
        else if(req==PICK_INPUT_DIR){pendingCpk=data.getData();createCpk();}
        else if(req==CREATE_CPK){Uri out=data.getData();runPack(pendingCpk,out);}
        else if(req==PICK_INSPECT){runInspect(data.getData());}
    }

    private void log(String s){main.post(()->log.append(s+"\n"));}
    private void setStatus(String s){main.post(()->status.setText("状态："+s));}

    private void runInspect(Uri uri){worker.submit(()->{
        try{
            setStatus("正在读取 CPK 信息...");
            File f=copyUriToTemp(uri,"inspect.cpk");
            CpkCore.Info i=CpkCore.inspect(f);
            setStatus("检查完成");
            log("CPK Mode="+i.mode()+", Files="+i.fileCount()+", Align="+i.alignment()+", Version="+i.version());
            log("ContentOffset="+i.contentOffset()+", ContentSize="+i.contentSize());
            int preview=Math.min(100,i.entries().size());
            for(int k=0;k<preview;k++){
                CpkCore.Entry e=i.entries().get(k);
                log(String.format(Locale.ROOT,"%05d  %s  %d -> %d%s",e.id(),e.path(),e.extractSize(),e.fileSize(),e.compressed()?" [CRILAYLA]":""));
            }
            if(i.entries().size()>preview)log("... 仅预览前 "+preview+" 个文件；实际文件总数="+i.entries().size());
        }catch(Exception e){setStatus("失败");log("ERROR: "+safeMessage(e));}
    });}

    private void runExtract(Uri in,Uri tree){worker.submit(()->{
        try{
            setStatus("正在复制输入 CPK...");
            DocumentFile sourceDoc=DocumentFile.fromSingleUri(this,in);
            String sourceName=sourceDoc!=null&&sourceDoc.getName()!=null?sourceDoc.getName():"archive.cpk";
            File cpk=copyUriToTemp(in,"input_"+System.nanoTime()+".cpk");
            DocumentFile dest=DocumentFile.fromTreeUri(this,tree);
            if(dest==null)throw new IOException("无法打开目标目录");
            String rootName=stripExt(sourceName);
            DocumentFile root=dest.createDirectory(rootName);
            if(root==null)throw new IOException("无法创建目标目录："+rootName);
            createNoMediaMarker(root);
            Map<String,DocumentFile> dirCache=new HashMap<>();
            dirCache.put("",root);
            setStatus("正在高速解包（已启用 .nomedia，不进入相册）...");
            log("🛡️ 已在解包根目录创建 .nomedia：图片/音频/视频不会被系统相册媒体库扫描");
            CpkCore.ExtractResult result = CpkCore.extractToSink(cpk,new CpkCore.ExtractSink(){
                @Override public void ensureDirectory(String relativeDir)throws Exception{ensureDocDir(root,dirCache,relativeDir);}
                @Override public OutputStream openFile(String relativePath)throws Exception{
                    String parent=parentPath(relativePath);
                    DocumentFile d=ensureDocDir(root,dirCache,parent);
                    String name=fileName(relativePath);
                    DocumentFile o=d.createFile("application/octet-stream",name);
                    if(o==null)throw new IOException("无法创建文件："+relativePath);
                    OutputStream out=getContentResolver().openOutputStream(o.getUri());
                    if(out==null)throw new IOException("无法打开输出："+relativePath);
                    return out;
                }
            },(m,c,t)->{
                if(c==1||c%250==0||c==t){setStatus("解包 "+c+" / "+t);log(m);}
            });
            if(result.failed()==0){
                setStatus("完成");
                log("✅ 解包完成："+rootName);
                log("✅ 成功 "+result.success()+" / "+result.total()+" 个文件");
            }else{
                setStatus("完成，但有 "+result.failed()+" 个文件失败");
                log("⚠️ 成功 "+result.success()+" / "+result.total()+" 个文件，失败 "+result.failed()+" 个");
                for(String f:result.failures())log("❌ "+f);
            }
        }catch(Exception e){setStatus("失败");log("ERROR: "+safeMessage(e));log("如是某个文件失败，v2 会明确指出失败路径；不会再静默跳过。");}
    });}

    private void createNoMediaMarker(DocumentFile root)throws IOException{
        DocumentFile marker=root.findFile(".nomedia");
        if(marker!=null && marker.isFile())return;
        marker=root.createFile("application/octet-stream",".nomedia");
        if(marker==null)throw new IOException("无法创建 .nomedia：图片可能会出现在系统相册");
        try(OutputStream out=getContentResolver().openOutputStream(marker.getUri())){
            if(out==null)throw new IOException("无法写入 .nomedia");
        }
    }

    private DocumentFile ensureDocDir(DocumentFile root,Map<String,DocumentFile> cache,String relativeDir)throws Exception{
        if(relativeDir==null||relativeDir.isEmpty())return root;
        DocumentFile existing=cache.get(relativeDir);
        if(existing!=null)return existing;
        String[] parts=relativeDir.split("/");
        DocumentFile cur=root;StringBuilder path=new StringBuilder();
        for(String part:parts){
            if(part.isEmpty())continue;
            if(path.length()>0)path.append('/');path.append(part);
            String key=path.toString();
            DocumentFile cached=cache.get(key);
            if(cached!=null){cur=cached;continue;}
            DocumentFile next=cur.createDirectory(part);
            if(next==null)throw new IOException("无法创建目录："+key);
            cache.put(key,next);cur=next;
        }
        return cur;
    }

    private void runPack(Uri dirUri,Uri outUri){worker.submit(()->{try{
        setStatus("正在读取输入文件夹...");
        File src=new File(tempRoot,"input_"+System.nanoTime());src.mkdirs();
        DocumentFile dir=DocumentFile.fromTreeUri(this,dirUri);if(dir==null)throw new IOException("无法打开输入目录");
        copyDocumentToFolder(dir,src);
        File out=new File(tempRoot,"packed_"+System.nanoTime()+".cpk");
        int align=Integer.parseInt(alignEdit.getText().toString().trim());
        CpkCore.Options opt=new CpkCore.Options(Math.max(256,align),compressSwitch.isChecked(),randomSwitch.isChecked(),crcSwitch.isChecked());
        setStatus("正在封装...");
        CpkCore.pack(src,out,opt,(m,c,t)->{if(c==1||c%100==0||c==t){setStatus("封装 "+c+" / "+t);log(m);}});
        setStatus("正在保存 CPK...");
        try(InputStream input=new BufferedInputStream(new FileInputStream(out),1024*1024);OutputStream os=new BufferedOutputStream(getContentResolver().openOutputStream(outUri),1024*1024)){
            if(os==null)throw new IOException("无法创建输出文件");
            byte[] b=new byte[1024*1024];int n;while((n=input.read(b))>0)os.write(b,0,n);
        }
        setStatus("完成");log("✅ CPK created");
    }catch(Exception e){setStatus("失败");log("ERROR: "+safeMessage(e));}});}

    private File copyUriToTemp(Uri uri,String name)throws Exception{
        File f=new File(tempRoot,name);if(f.exists())f.delete();
        try(InputStream in=new BufferedInputStream(getContentResolver().openInputStream(uri),1024*1024);OutputStream out=new BufferedOutputStream(new FileOutputStream(f),1024*1024)){
            if(in==null)throw new IOException("Cannot open URI");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)out.write(b,0,n);
        }return f;
    }
    private void copyDocumentToFolder(DocumentFile src,File dst)throws Exception{if(!src.isDirectory())throw new IOException("Input URI is not a folder");for(DocumentFile c:src.listFiles())copyDocumentNode(c,dst);}
    private void copyDocumentNode(DocumentFile src,File dst)throws Exception{if(src.isDirectory()){File here=new File(dst,src.getName()==null?"folder":src.getName());if(!here.mkdirs()&&!here.isDirectory())throw new IOException("Cannot create "+here);for(DocumentFile c:src.listFiles())copyDocumentNode(c,here);}else{File out=new File(dst,src.getName()==null?"file.bin":src.getName());try(InputStream in=new BufferedInputStream(getContentResolver().openInputStream(src.getUri()),1024*1024);OutputStream os=new BufferedOutputStream(new FileOutputStream(out),1024*1024)){if(in==null)throw new IOException("Cannot read "+src);byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)os.write(b,0,n);}}}

    private String stripExt(String n){if(n==null||n.isEmpty())return "cpk_extract";int p=n.lastIndexOf('.');return p>0?n.substring(0,p):n;}
    private String parentPath(String p){int i=p.lastIndexOf('/');return i<0?"":p.substring(0,i);}
    private String fileName(String p){int i=p.lastIndexOf('/');return i<0?p:p.substring(i+1);}
    private String safeMessage(Exception e){Throwable x=e;while(x.getCause()!=null&&x.getCause()!=x)x=x.getCause();String m=x.getMessage();return x.getClass().getSimpleName()+": "+(m==null?"unknown error":m);}
}
