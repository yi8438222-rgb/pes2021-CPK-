# PES CPK Tool Android v2.1

本版本在 v2 基础上新增媒体库隔离：每次解包都会在输出根目录创建标准的 `.nomedia` 标记，Android 系统相册/媒体库不会索引其中的 PNG/JPG/音频/视频文件。重新封装目录时会自动忽略 `.nomedia`，不会把它打进 CPK。

另外保留 v2 的高速直写、失败统计、完整路径、进度显示和 TOC 偏移修复。

# PES CPK Tool — Android

Android Studio project that reimplements the useful PES CPK workflow of the supplied Windows tool without depending on `CpkMaker.DLL` / .NET Framework.

## Included
- Select `.cpk` with Android Storage Access Framework and extract all files.
- Select a folder and build a CPK.
- PES/CRIWARE CPK Mode 1 (TOC) parser and builder.
- `@UTF` table parser/builder with big-endian fields.
- CRILAYLA decompression and optional compression.
- Configurable alignment; default 1024 bytes to mirror the supplied `settings.ini`.
- Progress log and file counts.

## Important compatibility note
The supplied Windows app is a WinForms .NET launcher around `CpkMaker.DLL` from CRI Middleware. That DLL is a 32-bit Windows binary, so it cannot simply be copied into an Android APK. This project reimplements the portable CPK/UTF/CRILAYLA parts instead.

It aims for **PES2021-compatible CPKs**, not byte-for-byte reproduction of every CpkMaker.dll output. CRC metadata, random padding, and unusual CPK modes are not guaranteed to match the original binary exactly.

## Build
Open this folder with Android Studio and let Gradle sync. Then run `app` on an Android 8.0+ device.

A prebuilt APK is not included because the current build environment does not contain the Android SDK/NDK toolchain needed to produce and device-test an APK.
