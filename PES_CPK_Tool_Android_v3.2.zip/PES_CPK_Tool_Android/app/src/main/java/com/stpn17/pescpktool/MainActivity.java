package com.stpn17.pescpktool;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.Handler;
import android.os.Looper;
import android.widget.*;

import androidx.documentfile.provider.DocumentFile;

import com.stpn17.pescpktool.core.CpkCore;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_CPK=10, PICK_EXTRACT_DIR=11, PICK_INPUT_DIR=12, CREATE_CPK=13, PICK_INSPECT=15;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private TextView status,log;
    private EditText alignEdit;
    private Switch compressSwitch, randomSwitch, crcSwitch;
    private Uri pendingCpk;
    private File tempRoot;

    @Override public void onCreate(Bundle b){super.onCreate(b); tempRoot=new File(getCacheDir(),"cpkwork");tempRoot.mkdirs();buildUi();}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(12));
        TextView title=new TextView(this);title.setText("PES CPK Tool Android v3.2");title.setTextSize(24);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=new TextView(this);sub.setText("极速直读 · 极速封装 · 免整包缓存 · .nomedia · PES2021 / CRIWARE CPK");sub.setTextSize(14);root.addView(sub,new LinearLayout.LayoutParams(-1,-2));

        Button extract=new Button(this);extract.setText("选择 .CPK → 高速解包");extract.setOnClickListener(v->pickCpk());root.addView(extract,lp());
        Button pack=new Button(this);pack.setText("选择文件夹 → 封装 .CPK");pack.setOnClickListener(v->pickInputDir());root.addView(pack,lp());
        Button inspect=new Button(this);inspect.setText("检查 CPK 信息");inspect.setOnClickListener(v->pickCpkForInspect());root.addView(inspect,lp());

        TextView cfg=new TextView(this);cfg.setText("CPK Build Options");cfg.setTextSize(18);cfg.setPadding(0,dp(10),0,dp(4));root.addView(cfg);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);TextView a=new TextView(this);a.setText("Align: ");a.setGravity(16);row.addView(a,new LinearLayout.LayoutParams(-2,-2));alignEdit=new EditText(this);alignEdit.setInputType(2);alignEdit.setText("1024");row.addView(alignEdit,new LinearLayout.LayoutParams(dp(110),-2));root.addView(row);
        compressSwitch=new Switch(this);compressSwitch.setText("Try CRILAYLA compression (experimental; raw fallback on failure)");compressSwitch.setChecked(false);root.addView(compressSwitch);
        randomSwitch=new Switch(this);randomSwitch.setText("Random padding");randomSwitch.setChecked(true);root.addView(randomSwitch);
        crcSwitch=new Switch(this);crcSwitch.setText("Enable CRC metadata (compatibility flag)");crcSwitch.setChecked(true);root.addView(crcSwitch);

        status=new TextView(this);status.setText("状态：就绪");status.setPadding(0,dp(8),0,dp(8));root.addView(status);
        ScrollView sv=new ScrollView(this);log=new TextView(this);log.setTextSize(12);log.setTextIsSelectable(true);log.setPadding(dp(8),dp(8),dp(8),dp(8));sv.addView(log);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private LinearLayout.LayoutParams lp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(6);return p;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void pickCpk(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_CPK);}
    private void pickCpkForInspect(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_INSPECT);}
    private void pickInputDir(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);startActivityForResult(i,PICK_INPUT_DIR);}
    private void pickExtractDir(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);startActivityForResult(i,PICK_EXTRACT_DIR);}
    private void createCpk(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"rebuilt.cpk");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,CREATE_CPK);}

    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;
        if(req==PICK_CPK){pendingCpk=data.getData();pickExtractDir();}
        else if(req==PICK_EXTRACT_DIR){Uri out=data.getData();runExtract(pendingCpk,out);}
        else if(req==PICK_INPUT_DIR){pendingCpk=data.getData();createCpk();}
        else if(req==CREATE_CPK){Uri out=data.getData();runPack(pendingCpk,out);}
        else if(req==PICK_INSPECT){runInspect(data.getData());}
    }

    private void log(String s){main.post(()->log.append(s+"\n"));}
    private void setStatus(String s){main.post(()->status.setText("状态："+s));}

    private void runInspect(Uri uri){worker.submit(()->{
        CpkCore.RandomAccessSource source=null;
        File fallbackTemp=null;
        try{
            setStatus("正在快速读取 CPK 信息...");
            try{
                source=new SeekableUriSource(uri);
                log("⚡ 检查模式：直接读取 CPK 头/TOC，不复制整个文件到缓存");
            }catch(Exception seekError){
                fallbackTemp=copyUriToTemp(uri,"inspect_"+System.nanoTime()+".cpk");
                source=CpkCore.openFileSource(fallbackTemp);
                log("ℹ️ 当前文件提供商不支持随机读取，检查模式自动使用兼容缓存");
            }
            CpkCore.Info i=CpkCore.inspect(source);
            setStatus("检查完成");
            log("CPK Mode="+i.mode()+", Files="+i.fileCount()+", Align="+i.alignment()+", Version="+i.version());
            log("ContentOffset="+i.contentOffset()+", ContentSize="+i.contentSize());
            int preview=Math.min(100,i.entries().size());
            for(int k=0;k<preview;k++){
                CpkCore.Entry e=i.entries().get(k);
                log(String.format(Locale.ROOT,"%05d  %s  %d -> %d%s",e.id(),e.path(),e.extractSize(),e.fileSize(),e.compressed()?" [CRILAYLA]":""));
            }
            if(i.entries().size()>preview)log("... 仅预览前 "+preview+" 个文件；实际文件总数="+i.entries().size());
        }catch(Exception e){setStatus("失败");log("ERROR: "+safeMessage(e));}
        finally{
            if(source!=null)try{source.close();}catch(Exception ignored){}
            if(fallbackTemp!=null)try{fallbackTemp.delete();}catch(Exception ignored){}
        }
    });}

    private void runExtract(Uri in,Uri tree){worker.submit(()->{
        CpkCore.RandomAccessSource source=null;
        File fallbackTemp=null;
        try{
            DocumentFile sourceDoc=DocumentFile.fromSingleUri(this,in);
            String sourceName=sourceDoc!=null&&sourceDoc.getName()!=null?sourceDoc.getName():"archive.cpk";
            DocumentFile dest=DocumentFile.fromTreeUri(this,tree);
            if(dest==null)throw new IOException("无法打开目标目录");
            String rootName=stripExt(sourceName);
            DocumentFile root=dest.createDirectory(rootName);
            if(root==null)throw new IOException("无法创建目标目录："+rootName);
            createNoMediaMarker(root);
            Map<String,DocumentFile> dirCache=new HashMap<>();
            dirCache.put("",root);

            // Prefer a seekable SAF file descriptor. This removes the previous full 1.3GB+ cache copy.
            try{
                source=new SeekableUriSource(in);
                setStatus("已启用极速直读：不复制整个 CPK 到缓存");
                log("⚡ 极速模式：直接从源文件随机读取，不再先复制整个 OBB/CPK 到应用缓存");
            }catch(Exception seekError){
                log("ℹ️ 当前文件提供商不支持随机读取，自动切换兼容模式：先复制到缓存");
                fallbackTemp=copyUriToTemp(in,"input_"+System.nanoTime()+".cpk");
                source=CpkCore.openFileSource(fallbackTemp);
                setStatus("兼容模式：正在准备 CPK...");
            }

            setStatus("正在高速解包（已启用 .nomedia）...");
            log("🛡️ .nomedia 已启用：解析出的图片/音频/视频不会进入系统相册媒体库");
            CpkCore.ExtractResult result = CpkCore.extractToSink(source,new CpkCore.ExtractSink(){
                @Override public void ensureDirectory(String relativeDir)throws Exception{ensureDocDir(root,dirCache,relativeDir);}
                private DocumentFile createOutput(String relativePath)throws Exception{
                    String parent=parentPath(relativePath);
                    DocumentFile d=ensureDocDir(root,dirCache,parent);
                    String name=fileName(relativePath);
                    DocumentFile o=d.createFile("application/octet-stream",name);
                    if(o==null)throw new IOException("无法创建文件："+relativePath);
                    return o;
                }
                @Override public OutputStream openFile(String relativePath)throws Exception{
                    DocumentFile o=createOutput(relativePath);
                    OutputStream out=getContentResolver().openOutputStream(o.getUri(),"w");
                    if(out==null)throw new IOException("无法打开输出："+relativePath);
                    return out;
                }
                @Override public WritableByteChannel openChannel(String relativePath)throws Exception{
                    DocumentFile o=createOutput(relativePath);
                    ParcelFileDescriptor pfd=getContentResolver().openFileDescriptor(o.getUri(),"w");
                    if(pfd==null)throw new IOException("无法打开输出通道："+relativePath);
                    ParcelFileDescriptor.AutoCloseOutputStream out=new ParcelFileDescriptor.AutoCloseOutputStream(pfd);
                    return out.getChannel();
                }
                @Override public void deleteFile(String relativePath)throws Exception{
                    String parent=parentPath(relativePath);
                    DocumentFile d=ensureDocDir(root,dirCache,parent);
                    DocumentFile f=d.findFile(fileName(relativePath));
                    if(f!=null)f.delete();
                }
            },(m,c,t)->{
                if(c==1||c%500==0||c==t){setStatus("解包 "+c+" / "+t);log(m);}
            });
            if(result.failed()==0){
                setStatus("完成");
                log("✅ 解包完成："+rootName);
                log("✅ 成功 "+result.success()+" / "+result.total()+" 个文件");
            }else{
                setStatus("完成，但有 "+result.failed()+" 个文件失败");
                log("⚠️ 成功 "+result.success()+" / "+result.total()+" 个文件，失败 "+result.failed()+" 个");
                for(String f:result.failures())log("❌ "+f);
            }
        }catch(Exception e){
            setStatus("失败");
            log("ERROR: "+safeMessage(e));
        }finally{
            if(source!=null)try{source.close();}catch(Exception ignored){}
            if(fallbackTemp!=null)try{fallbackTemp.delete();}catch(Exception ignored){}
        }
    });}

    /** Seekable SAF source. Falls back automatically when the provider exposes a non-seekable pipe. */
    private final class SeekableUriSource implements CpkCore.RandomAccessSource {
        private final ParcelFileDescriptor pfd;
        private final ParcelFileDescriptor.AutoCloseInputStream input;
        private final FileChannel channel;
        SeekableUriSource(Uri uri)throws Exception{
            pfd=getContentResolver().openFileDescriptor(uri,"r");
            if(pfd==null)throw new IOException("无法打开源文件");
            input=new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            channel=input.getChannel();
            // Force a real seek/size test. Pipes/providers without random access are rejected here.
            channel.size();
            channel.position(0);
        }
        @Override public long size()throws IOException{return channel.size();}
        @Override public int read(long position,byte[] buffer,int off,int len)throws IOException{
            return channel.read(ByteBuffer.wrap(buffer,off,len),position);
        }
        @Override public long transferTo(long position,long count,WritableByteChannel out)throws IOException{
            long remain=count;
            while(remain>0){
                long n=channel.transferTo(position,remain,out);
                if(n<=0)return CpkCore.RandomAccessSource.super.transferTo(position,remain,out);
                position+=n;
                remain-=n;
            }
            return count;
        }
        @Override public void close()throws IOException{input.close();}
    }

    private void createNoMediaMarker(DocumentFile root)throws IOException{
        DocumentFile marker=root.findFile(".nomedia");
        if(marker!=null && marker.isFile())return;
        marker=root.createFile("application/octet-stream",".nomedia");
        if(marker==null)throw new IOException("无法创建 .nomedia：图片可能会出现在系统相册");
        try(OutputStream out=getContentResolver().openOutputStream(marker.getUri())){
            if(out==null)throw new IOException("无法写入 .nomedia");
        }
    }

    private DocumentFile ensureDocDir(DocumentFile root,Map<String,DocumentFile> cache,String relativeDir)throws Exception{
        if(relativeDir==null||relativeDir.isEmpty())return root;
        DocumentFile existing=cache.get(relativeDir);
        if(existing!=null)return existing;
        String[] parts=relativeDir.split("/");
        DocumentFile cur=root;StringBuilder path=new StringBuilder();
        for(String part:parts){
            if(part.isEmpty())continue;
            if(path.length()>0)path.append('/');path.append(part);
            String key=path.toString();
            DocumentFile cached=cache.get(key);
            if(cached!=null){cur=cached;continue;}
            DocumentFile next=cur.createDirectory(part);
            if(next==null)throw new IOException("无法创建目录："+key);
            cache.put(key,next);cur=next;
        }
        return cur;
    }

    private void runPack(Uri dirUri,Uri outUri){worker.submit(()->{
        try{
            setStatus("正在扫描输入文件夹...");
            DocumentFile dir=DocumentFile.fromTreeUri(this,dirUri);
            if(dir==null||!dir.isDirectory())throw new IOException("无法打开输入目录");

            List<CpkCore.PackSource> sources=new ArrayList<>();
            collectPackSources(dir,"",sources);
            if(sources.isEmpty())throw new IOException("输入目录没有可封装的文件");

            int align=Integer.parseInt(alignEdit.getText().toString().trim());
            CpkCore.Options opt=new CpkCore.Options(Math.max(256,align),compressSwitch.isChecked(),randomSwitch.isChecked(),crcSwitch.isChecked());
            log("⚡ 极速封装：不再把整个输入目录复制到 App 缓存，也不再把生成的 CPK 再复制一次");
            log("📦 待封装文件："+sources.size()+" 个");

            OutputStream raw=getContentResolver().openOutputStream(outUri,"w");
            if(raw==null)throw new IOException("无法创建输出 CPK");
            try(OutputStream out=raw){
                setStatus("正在极速封装...");
                CpkCore.packSources(sources,out,opt,(m,c,t)->{
                    if(c==1||c%1000==0||c==t){
                        setStatus("封装 "+c+" / "+t);
                        log(m);
                    }
                });
            }
            setStatus("完成");
            log("✅ CPK created（已直接写入目标文件）");
        }catch(Exception e){
            setStatus("失败");
            log("ERROR: "+safeMessage(e));
        }
    });}

    private void collectPackSources(DocumentFile node,String relativeDir,List<CpkCore.PackSource> out)throws Exception{
        DocumentFile[] children=node.listFiles();
        for(DocumentFile child:children){
            String name=child.getName();
            if(name==null||name.isEmpty())name="file.bin";
            if(child.isDirectory()){
                String next=relativeDir.isEmpty()?name:relativeDir+"/"+name;
                collectPackSources(child,next,out);
            }else{
                if(name.equalsIgnoreCase(".nomedia"))continue;
                String archivePath=relativeDir.isEmpty()?name:relativeDir+"/"+name;
                final DocumentFile file=child;
                out.add(new CpkCore.PackSource(){
                    @Override public String archivePath(){return archivePath;}
                    @Override public long size()throws Exception{
                        long len=file.length();
                        if(len<0)throw new IOException("无法读取文件大小："+archivePath);
                        return len;
                    }
                    @Override public InputStream open()throws Exception{
                        InputStream in=getContentResolver().openInputStream(file.getUri());
                        if(in==null)throw new IOException("无法读取文件："+archivePath);
                        return in;
                    }
                });
            }
        }
    }

    private File copyUriToTemp(Uri uri,String name)throws Exception{
        File f=new File(tempRoot,name);if(f.exists())f.delete();
        try(InputStream in=new BufferedInputStream(getContentResolver().openInputStream(uri),1024*1024);OutputStream out=new BufferedOutputStream(new FileOutputStream(f),1024*1024)){
            if(in==null)throw new IOException("Cannot open URI");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)out.write(b,0,n);
        }return f;
    }
    private void copyDocumentToFolder(DocumentFile src,File dst)throws Exception{if(!src.isDirectory())throw new IOException("Input URI is not a folder");for(DocumentFile c:src.listFiles())copyDocumentNode(c,dst);}
    private void copyDocumentNode(DocumentFile src,File dst)throws Exception{if(src.isDirectory()){File here=new File(dst,src.getName()==null?"folder":src.getName());if(!here.mkdirs()&&!here.isDirectory())throw new IOException("Cannot create "+here);for(DocumentFile c:src.listFiles())copyDocumentNode(c,here);}else{File out=new File(dst,src.getName()==null?"file.bin":src.getName());try(InputStream in=new BufferedInputStream(getContentResolver().openInputStream(src.getUri()),1024*1024);OutputStream os=new BufferedOutputStream(new FileOutputStream(out),1024*1024)){if(in==null)throw new IOException("Cannot read "+src);byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)os.write(b,0,n);}}}

    private String stripExt(String n){if(n==null||n.isEmpty())return "cpk_extract";int p=n.lastIndexOf('.');return p>0?n.substring(0,p):n;}
    private String parentPath(String p){int i=p.lastIndexOf('/');return i<0?"":p.substring(0,i);}
    private String fileName(String p){int i=p.lastIndexOf('/');return i<0?p:p.substring(i+1);}
    private String safeMessage(Exception e){Throwable x=e;while(x.getCause()!=null&&x.getCause()!=x)x=x.getCause();String m=x.getMessage();return x.getClass().getSimpleName()+": "+(m==null?"unknown error":m);}
}
