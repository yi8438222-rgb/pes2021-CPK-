package com.stpn17.pescpktool.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.*;

/** PES/CRIWARE CPK reader and Mode-1 builder. */
public final class CpkCore {
    public interface Listener { void onProgress(String message, int current, int total); }
    public static final Listener NOOP=(m,c,t)->{};
    public record Options(int alignment, boolean tryCompress, boolean randomPadding, boolean enableCrc) {}
    public record Entry(String dir,String name,long offset,long fileSize,long extractSize,long id){
        public String path(){return dir==null||dir.isEmpty()?name:dir+"/"+name;}
        public boolean compressed(){return extractSize>fileSize;}
    }
    public record Info(int mode,int alignment,long fileCount,long contentOffset,long contentSize,String version,List<Entry> entries){ }

    /** Destination abstraction used by Android SAF without forcing Android classes into the core. */
    public interface ExtractSink {
        void ensureDirectory(String relativeDir) throws Exception;
        OutputStream openFile(String relativePath) throws Exception;
        default WritableByteChannel openChannel(String relativePath) throws Exception { return null; }
        default void deleteFile(String relativePath) throws Exception {}
    }

    /** Minimal random-access input abstraction. Android can back this with a seekable SAF file descriptor. */
    public interface RandomAccessSource extends Closeable {
        long size() throws IOException;
        int read(long position, byte[] buffer, int off, int len) throws IOException;
        default void readFully(long position, byte[] buffer) throws IOException {
            readFully(position, buffer, 0, buffer.length);
        }
        default void readFully(long position, byte[] buffer, int off, int len) throws IOException {
            int done=0;
            while(done<len){
                int n=read(position+done,buffer,off+done,len-done);
                if(n<0)throw new EOFException("Unexpected end of CPK input");
                if(n==0)throw new IOException("Zero-byte read while reading CPK input");
                done+=n;
            }
        }
        default long transferTo(long position,long count,WritableByteChannel out)throws IOException{
            byte[] buffer=new byte[4*1024*1024];
            long remain=count;
            while(remain>0){
                int want=(int)Math.min(remain,buffer.length);
                int n=read(position,buffer,0,want);
                if(n<0)throw new EOFException("Unexpected end of CPK content");
                if(n==0)throw new IOException("Zero-byte read while copying CPK content");
                ByteBuffer bb=ByteBuffer.wrap(buffer,0,n);
                while(bb.hasRemaining())out.write(bb);
                position+=n;
                remain-=n;
            }
            return count;
        }
    }
    public record ExtractResult(int total,int success,int failed,List<String> failures) {}
    private record Parsed(Info info,long tocOffset) {}

    private static final class FileSource implements RandomAccessSource {
        private final RandomAccessFile raf;
        private final FileChannel channel;
        FileSource(File file)throws IOException{raf=new RandomAccessFile(file,"r");channel=raf.getChannel();}
        @Override public long size()throws IOException{return channel.size();}
        @Override public int read(long position,byte[] buffer,int off,int len)throws IOException{return channel.read(ByteBuffer.wrap(buffer,off,len),position);}
        @Override public long transferTo(long position,long count,WritableByteChannel out)throws IOException{
            long remain=count;
            while(remain>0){
                long n=channel.transferTo(position,remain,out);
                if(n<=0)return RandomAccessSource.super.transferTo(position,remain,out);
                position+=n;remain-=n;
            }
            return count;
        }
        @Override public void close()throws IOException{raf.close();}
    }

    private CpkCore(){}
    private static long le32(byte[] b,int p){return (b[p]&255L)|((b[p+1]&255L)<<8)|((b[p+2]&255L)<<16)|((b[p+3]&255L)<<24);}
    private static void putLe32(OutputStream o,long v)throws IOException{o.write((int)v&255);o.write((int)(v>>>8)&255);o.write((int)(v>>>16)&255);o.write((int)(v>>>24)&255);}
    private static void pad(OutputStream out,long n,boolean random)throws IOException{byte[] b=new byte[8192];java.util.Random r=random?new java.util.Random(0x17C0FFEE):null;while(n>0){int k=(int)Math.min(n,b.length);if(r!=null)r.nextBytes(b);else Arrays.fill(b,(byte)0);out.write(b,0,k);n-=k;}}
    private static long align(long v,long a){return (v+a-1)/a*a;}
    private static long num2(Object x){return x instanceof Number?((Number)x).longValue():Long.parseLong(String.valueOf(x));}

    public static RandomAccessSource openFileSource(File file)throws IOException{return new FileSource(file);}

    public static Info inspect(File cpk)throws Exception{
        try(RandomAccessSource src=new FileSource(cpk)){return inspectParsed(src).info();}
    }

    public static Info inspect(RandomAccessSource src)throws Exception{return inspectParsed(src).info();}

    private static Parsed inspectParsed(RandomAccessSource src)throws Exception{
        byte[] hdr=new byte[0x800];
        src.readFully(0,hdr);
        checkMagic(hdr,"CPK ");
        UtfTable t=UtfTable.parse(Arrays.copyOfRange(hdr,16,hdr.length));
        long tocOff=getLong(t,"TocOffset",0),tocSize=getLong(t,"TocSize",0),contentOff=getLong(t,"ContentOffset",0),contentSize=getLong(t,"ContentSize",0);
        int align=(int)getLong(t,"Align",0x800);
        int mode=(int)getLong(t,"CpkMode",1);
        String ver=getString(t,"Tvers","");
        List<Entry> entries=new ArrayList<>();
        if(tocOff>0&&tocSize>0){
            if(tocSize>Integer.MAX_VALUE) throw new IOException("TOC too large for this build: "+tocSize);
            byte[] toc=new byte[(int)tocSize];
            src.readFully(tocOff,toc);
            checkMagic(toc,"TOC ");
            UtfTable tt=UtfTable.parse(Arrays.copyOfRange(toc,16,toc.length));
            for(int i=0;i<tt.rows.size();i++){
                String d=getString(tt,i,"DirName","");
                String f=getString(tt,i,"FileName","");
                long fs=getLong(tt,i,"FileSize",0),xs=getLong(tt,i,"ExtractSize",fs),off=getLong(tt,i,"FileOffset",0),id=getLong(tt,i,"ID",i);
                entries.add(new Entry(d,f,off,fs,xs,id));
            }
        } else if(getLong(t,"ItocOffset",0)>0) {
            throw new UnsupportedOperationException("This Android build currently reads TOC-mode CPKs only; this archive appears to use ITOC mode.");
        }
        return new Parsed(new Info(mode,align,entries.size(),contentOff,contentSize,ver,Collections.unmodifiableList(entries)),tocOff);
    }

    /** Legacy file-output extractor. Kept for non-Android callers. */
    public static void extract(File cpk,File outDir,Listener listener)throws Exception{
        Files.createDirectories(outDir.toPath());
        extractToSink(new FileSource(cpk),new ExtractSink(){
            @Override public void ensureDirectory(String relativeDir)throws Exception{Files.createDirectories(outDir.toPath().resolve(relativeDir));}
            @Override public OutputStream openFile(String relativePath)throws Exception{
                Path p=outDir.toPath().resolve(relativePath);
                Path parent=p.getParent();
                if(parent!=null)Files.createDirectories(parent);
                return new BufferedOutputStream(Files.newOutputStream(p),4*1024*1024);
            }
            @Override public void deleteFile(String relativePath)throws Exception{Files.deleteIfExists(outDir.toPath().resolve(relativePath));}
        },listener);
    }

    /** High-efficiency extractor. For a seekable source it avoids copying the entire CPK to cache and uses channel-to-channel transfer for uncompressed entries. */
    public static ExtractResult extractToSink(File cpk,ExtractSink sink,Listener listener)throws Exception{
        return extractToSink(new FileSource(cpk),sink,listener);
    }

    public static ExtractResult extractToSink(RandomAccessSource src,ExtractSink sink,Listener listener)throws Exception{
        Parsed parsed=inspectParsed(src);
        Info info=parsed.info();
        List<String> failures=new ArrayList<>();
        int success=0;
        byte[] buffer=new byte[4*1024*1024];
        long sourceSize=src.size();
        // Keep the v2.1 CRIWARE baseline rule that already produced complete PES CPK extraction.
        long baseOffset=Math.min(info.contentOffset(),Math.min(parsed.tocOffset(),0x800L));
        for(int i=0;i<info.entries.size();i++){
            Entry e=info.entries.get(i);
            String path=safePath(e.path());
            try{
                String parent=parentPath(path);
                if(!parent.isEmpty())sink.ensureDirectory(parent);
                if(e.fileSize()<0||e.extractSize()<0)throw new IOException("Negative CPK size");
                long absolute=baseOffset+e.offset();
                if(absolute<0||e.fileSize()>sourceSize-absolute)throw new IOException("CPK entry exceeds input size");
                if(e.compressed()){
                    if(e.fileSize()>Integer.MAX_VALUE)throw new IOException("Compressed file too large for memory decode: "+e.fileSize());
                    byte[] raw=new byte[(int)e.fileSize()];
                    src.readFully(absolute,raw);
                    byte[] data=Crilayla.isCompressed(raw)?Crilayla.decompress(raw):raw;
                    try(OutputStream out=new BufferedOutputStream(sink.openFile(path),4*1024*1024)){out.write(data);}
                }else{
                    WritableByteChannel outChannel=sink.openChannel(path);
                    if(outChannel!=null){
                        try(WritableByteChannel out=outChannel){
                            src.transferTo(absolute,e.fileSize(),out);
                        }
                    }else{
                        try(OutputStream out=new BufferedOutputStream(sink.openFile(path),4*1024*1024)){
                            long remain=e.fileSize();
                            long pos=absolute;
                            while(remain>0){
                                int want=(int)Math.min(remain,buffer.length);
                                int n=src.read(pos,buffer,0,want);
                                if(n<0)throw new EOFException("Unexpected end of CPK content");
                                if(n==0)throw new IOException("Zero-byte read while copying CPK content");
                                out.write(buffer,0,n);
                                pos+=n;
                                remain-=n;
                            }
                        }
                    }
                }
                success++;
                listener.onProgress("已解包: "+path,i+1,info.entries.size());
            }catch(Exception ex){
                failures.add(path+" → "+(ex.getMessage()==null?ex.getClass().getSimpleName():ex.getMessage()));
                try{sink.deleteFile(path);}catch(Exception ignored){}
                listener.onProgress("失败: "+path+" → "+(ex.getMessage()==null?ex.getClass().getSimpleName():ex.getMessage()),i+1,info.entries.size());
            }
        }
        return new ExtractResult(info.entries.size(),success,failures.size(),Collections.unmodifiableList(failures));
    }

    private static void checkMagic(byte[] b,String s)throws IOException{for(int i=0;i<4;i++)if(b[i]!=(byte)s.charAt(i))throw new IOException("Invalid CPK/TOC magic");}
    private static long getLong(UtfTable t,String c,long def){return t.has(c)&&!t.rows.isEmpty()?num2(t.get(0,c)):def;}
    private static String getString(UtfTable t,String c,String def){return t.has(c)&&!t.rows.isEmpty()?String.valueOf(t.get(0,c)):def;}
    private static long getLong(UtfTable t,int row,String c,long def){return t.has(c)?num2(t.get(row,c)):def;}
    private static String getString(UtfTable t,int row,String c,String def){return t.has(c)?String.valueOf(t.get(row,c)):def;}

    private static String safePath(String p)throws IOException{
        if(p==null||p.isEmpty())throw new IOException("Empty archive path");
        String normalized=p.replace('\\','/');
        while(normalized.startsWith("/"))normalized=normalized.substring(1);
        String[] parts=normalized.split("/");
        StringBuilder out=new StringBuilder();
        for(String part:parts){
            if(part.isEmpty()||".".equals(part))continue;
            if("..".equals(part))throw new IOException("Unsafe archive path: "+p);
            if(part.indexOf('\0')>=0)throw new IOException("NUL in archive path: "+p);
            if(out.length()>0)out.append('/');
            out.append(part);
        }
        if(out.length()==0)throw new IOException("Empty archive path: "+p);
        return out.toString();
    }
    private static String parentPath(String p){int i=p.lastIndexOf('/');return i<0?"":p.substring(0,i);}

    private static final class Fi {String archivePath,dir,name,source;long extractSize,fileSize,offset,id;File staged;PackSource packSource;}
    public interface PackSource {
        String archivePath();
        long size() throws Exception;
        InputStream open() throws Exception;
    }

    private static final class Padder {
        private final byte[] buffer = new byte[1024 * 1024];
        private final Random random;
        Padder(boolean randomPadding) {
            random = randomPadding ? new Random(0x17C0FFEE) : null;
            if (random == null) Arrays.fill(buffer, (byte) 0);
        }
        void write(OutputStream out, long count) throws IOException {
            while (count > 0) {
                int n = (int) Math.min(count, buffer.length);
                if (random != null) random.nextBytes(buffer);
                out.write(buffer, 0, n);
                count -= n;
            }
        }
    }

    /** High-speed packer for Android SAF and other streaming sources. */
    public static void packSources(List<PackSource> sources, OutputStream destination, Options opt, Listener listener) throws Exception {
        if (sources == null || destination == null) throw new IllegalArgumentException("sources/destination");
        List<PackSource> ordered = new ArrayList<>(sources);
        ordered.removeIf(Objects::isNull);
        ordered.sort(Comparator.comparing(s -> sortKey(s.archivePath())));

        List<Fi> fs = new ArrayList<>(ordered.size());
        Path stage = null;
        if (opt.tryCompress) stage = Files.createTempDirectory("pes-cpk-stage-");
        try {
            int total = ordered.size();
            for (int i = 0; i < total; i++) {
                PackSource src = ordered.get(i);
                Fi f = new Fi();
                f.packSource = src;
                f.archivePath = safeArchivePath(src.archivePath());
                int last = f.archivePath.lastIndexOf('/');
                f.dir = last >= 0 ? f.archivePath.substring(0, last) : "";
                f.name = last >= 0 ? f.archivePath.substring(last + 1) : f.archivePath;
                f.id = i;
                f.extractSize = src.size();
                if (f.extractSize < 0) throw new IOException("Negative file size: " + f.archivePath);

                if (opt.tryCompress && f.extractSize >= 256 && f.extractSize <= 64L * 1024 * 1024) {
                    try (InputStream in = new BufferedInputStream(src.open(), 4 * 1024 * 1024);
                         ByteArrayOutputStream mem = new ByteArrayOutputStream((int) Math.min(f.extractSize, 8L * 1024 * 1024))) {
                        byte[] b = new byte[4 * 1024 * 1024];
                        long remain = f.extractSize;
                        while (remain > 0) {
                            int want = (int) Math.min(remain, b.length);
                            int n = in.read(b, 0, want);
                            if (n < 0) throw new EOFException("Unexpected end of source: " + f.archivePath);
                            if (n == 0) continue;
                            mem.write(b, 0, n);
                            remain -= n;
                        }
                        byte[] raw = mem.toByteArray();
                        try {
                            byte[] cmp = Crilayla.compress(raw);
                            if (cmp.length < raw.length) {
                                f.fileSize = cmp.length;
                                f.staged = stage.resolve(String.format(Locale.ROOT, "%06d.bin", i)).toFile();
                                Files.write(f.staged.toPath(), cmp);
                            } else {
                                f.fileSize = f.extractSize;
                            }
                        } catch (Throwable compressionError) {
                            f.fileSize = f.extractSize;
                            listener.onProgress("Compression skipped (raw fallback): " + f.archivePath, i + 1, total);
                        }
                    }
                } else {
                    f.fileSize = f.extractSize;
                }
                fs.add(f);
                if (i == 0 || ((i + 1) % 1000 == 0) || i + 1 == total) {
                    listener.onProgress("Prepared: " + f.archivePath, i + 1, total);
                }
            }

            // The encoded TOC size is independent of numeric offsets, so probe once and build once with final offsets.
            byte[] tocProbeUtf = buildToc(fs).build();
            long tocChunk = align(16L + tocProbeUtf.length, opt.alignment);
            long off = tocChunk;
            for (Fi f : fs) {
                f.offset = off;
                off += align(f.fileSize, opt.alignment);
            }
            byte[] tocUtf = buildToc(fs).build();
            if (align(16L + tocUtf.length, opt.alignment) != tocChunk) {
                throw new IOException("TOC size changed unexpectedly");
            }

            long contentSize = 0, packed = 0, extracted = 0;
            for (Fi f : fs) {
                contentSize += align(f.fileSize, opt.alignment);
                packed += f.fileSize;
                extracted += f.extractSize;
            }
            long contentOffset = 0x800L + tocChunk;
            long etocOffset = contentOffset + contentSize;

            UtfTable header = buildHeader(fs.size(), opt.alignment, contentOffset, contentSize,
                    tocUtf.length + 16L, etocOffset, packed, extracted);
            byte[] headerUtf = header.build();
            byte[] headerChunk = new byte[0x800];
            System.arraycopy(new byte[]{'C','P','K',' '}, 0, headerChunk, 0, 4);
            headerChunk[4] = (byte) 0xff;
            putLe32At(headerChunk, 8, headerUtf.length);
            System.arraycopy(headerUtf, 0, headerChunk, 16, Math.min(headerUtf.length, headerChunk.length - 16));
            System.arraycopy("(c)CRI".getBytes(StandardCharsets.US_ASCII), 0, headerChunk, 0x800 - 6, 6);

            byte[] tocChunkBytes = new byte[(int) tocChunk];
            System.arraycopy(new byte[]{'T','O','C',' '}, 0, tocChunkBytes, 0, 4);
            putLe32At(tocChunkBytes, 4, 0xff);
            putLe32At(tocChunkBytes, 8, tocUtf.length);
            System.arraycopy(tocUtf, 0, tocChunkBytes, 16, tocUtf.length);

            UtfTable etoc = buildEtoc(fs.size());
            byte[] etocUtf = etoc.build();
            byte[] etocChunk = new byte[16 + etocUtf.length];
            System.arraycopy(new byte[]{'E','T','O','C'}, 0, etocChunk, 0, 4);
            putLe32At(etocChunk, 4, 0xff);
            putLe32At(etocChunk, 8, etocUtf.length);
            System.arraycopy(etocUtf, 0, etocChunk, 16, etocUtf.length);

            Padder padder = new Padder(opt.randomPadding);
            try (OutputStream out = new BufferedOutputStream(destination, 4 * 1024 * 1024)) {
                out.write(headerChunk);
                out.write(tocChunkBytes);
                byte[] copyBuffer = new byte[4 * 1024 * 1024];
                for (int i = 0; i < fs.size(); i++) {
                    Fi f = fs.get(i);
                    if (f.staged != null) {
                        try (InputStream in = new BufferedInputStream(Files.newInputStream(f.staged.toPath()), 4 * 1024 * 1024)) {
                            copyStream(in, out, copyBuffer);
                        }
                    } else {
                        try (InputStream in = new BufferedInputStream(f.packSource.open(), 4 * 1024 * 1024)) {
                            copyStream(in, out, copyBuffer);
                        }
                    }
                    padder.write(out, align(f.fileSize, opt.alignment) - f.fileSize);
                    if (i == 0 || ((i + 1) % 100 == 0) || i + 1 == fs.size()) {
                        listener.onProgress("Packed: " + f.archivePath, i + 1, fs.size());
                    }
                }
                out.write(etocChunk);
            }
        } finally {
            if (stage != null) {
                try (var walk = Files.walk(stage)) {
                    walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                        try { Files.deleteIfExists(p); } catch (IOException ignored) {}
                    });
                }
            }
        }
    }

    private static void copyStream(InputStream in, OutputStream out, byte[] buffer) throws IOException {
        int n;
        while ((n = in.read(buffer)) != -1) {
            if (n > 0) out.write(buffer, 0, n);
        }
    }

    private static String safeArchivePath(String p) throws IOException {
        if (p == null || p.isEmpty()) throw new IOException("Empty archive path");
        String normalized = p.replace('\\', '/');
        while (normalized.startsWith("/")) normalized = normalized.substring(1);
        String[] parts = normalized.split("/");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty() || ".".equals(part)) continue;
            if ("..".equals(part)) throw new IOException("Unsafe archive path: " + p);
            if (part.indexOf('\0') >= 0) throw new IOException("NUL in archive path: " + p);
            if (out.length() > 0) out.append('/');
            out.append(part);
        }
        if (out.length() == 0) throw new IOException("Empty archive path");
        return out.toString();
    }


    public static void pack(File inputDir,File output,Options opt,Listener listener)throws Exception{
        if(!inputDir.isDirectory())throw new IOException("Input is not a directory");
        Files.createDirectories(output.toPath().getParent()==null?output.toPath().toAbsolutePath().getParent():output.toPath().getParent());
        List<Fi> fs=new ArrayList<>();
        try(var walk=Files.walk(inputDir.toPath())){walk.filter(Files::isRegularFile).filter(p -> !p.getFileName().toString().equalsIgnoreCase(".nomedia")).forEach(p->{Fi f=new Fi();f.source=p.toString();f.archivePath=inputDir.toPath().relativize(p).toString().replace(File.separatorChar,'/');fs.add(f);});}
        fs.sort(Comparator.comparing(a->sortKey(a.archivePath)));
        Path stage=Files.createTempDirectory("pes-cpk-stage-");
        try{
            for(int i=0;i<fs.size();i++){
                Fi f=fs.get(i);int last=f.archivePath.lastIndexOf('/');f.dir=last>=0?f.archivePath.substring(0,last):"";f.name=last>=0?f.archivePath.substring(last+1):f.archivePath;f.id=i;File src=new File(f.source);f.extractSize=src.length();
                if(opt.tryCompress && f.extractSize>=256){
                    byte[] srcBytes=Files.readAllBytes(src.toPath());
                    try{
                        byte[] cmp=Crilayla.compress(srcBytes);
                        if(cmp.length<srcBytes.length){
                            f.fileSize=cmp.length;
                            f.staged=stage.resolve(String.format(Locale.ROOT,"%06d.bin",i)).toFile();
                            Files.write(f.staged.toPath(),cmp);
                        }else{
                            f.fileSize=f.extractSize;
                        }
                    }catch(Throwable compressionError){
                        f.fileSize=f.extractSize;
                        listener.onProgress("Compression skipped (raw fallback): "+f.archivePath,i+1,fs.size());
                    }
                } else f.fileSize=f.extractSize;
                listener.onProgress("Prepared: "+f.archivePath,i+1,fs.size());
            }
            UtfTable toc=buildToc(fs);byte[] tocUtf=toc.build();long tocChunk=align(16L+tocUtf.length,opt.alignment);
            long off=tocChunk;for(Fi f:fs){f.offset=off;off+=align(f.fileSize,opt.alignment);}toc=buildToc(fs);tocUtf=toc.build();tocChunk=align(16L+tocUtf.length,opt.alignment);
            off=tocChunk;for(Fi f:fs){f.offset=off;off+=align(f.fileSize,opt.alignment);}toc=buildToc(fs);tocUtf=toc.build();tocChunk=align(16L+tocUtf.length,opt.alignment);
            long contentSize=0;for(Fi f:fs)contentSize+=align(f.fileSize,opt.alignment);
            long contentOffset=0x800L+tocChunk;
            long etocOffset=contentOffset+contentSize;
            long totalData=0,packed=0;for(Fi f:fs){packed+=f.fileSize;totalData+=f.extractSize;}
            UtfTable header=buildHeader(fs.size(),opt.alignment,contentOffset,contentSize,tocUtf.length+16,etocOffset,packed,totalData);byte[] headerUtf=header.build();
            byte[] headerChunk=new byte[0x800];System.arraycopy(new byte[]{'C','P','K',' '},0,headerChunk,0,4);headerChunk[4]=(byte)0xff;putLe32At(headerChunk,8,headerUtf.length);System.arraycopy(headerUtf,0,headerChunk,16,Math.min(headerUtf.length,headerChunk.length-16));System.arraycopy("(c)CRI".getBytes(StandardCharsets.US_ASCII),0,headerChunk,0x800-6,6);
            byte[] tocChunkBytes=new byte[(int)tocChunk];System.arraycopy(new byte[]{'T','O','C',' '},0,tocChunkBytes,0,4);putLe32At(tocChunkBytes,4,0xff);putLe32At(tocChunkBytes,8,tocUtf.length);System.arraycopy(tocUtf,0,tocChunkBytes,16,tocUtf.length);
            UtfTable etoc=buildEtoc(fs.size());byte[] etocUtf=etoc.build();byte[] etocChunk=new byte[16+etocUtf.length];System.arraycopy(new byte[]{'E','T','O','C'},0,etocChunk,0,4);putLe32At(etocChunk,4,0xff);putLe32At(etocChunk,8,etocUtf.length);System.arraycopy(etocUtf,0,etocChunk,16,etocUtf.length);
            try(OutputStream out=new BufferedOutputStream(new FileOutputStream(output),1024*1024)){
                out.write(headerChunk);out.write(tocChunkBytes);
                for(int i=0;i<fs.size();i++){
                    Fi f=fs.get(i);Path p=f.staged!=null?f.staged.toPath():Path.of(f.source);
                    try(InputStream in=new BufferedInputStream(Files.newInputStream(p),1024*1024)){in.transferTo(out);}long pad=align(f.fileSize,opt.alignment)-f.fileSize;pad(out,pad,opt.randomPadding);listener.onProgress("Packed: "+f.archivePath,i+1,fs.size());
                }
                out.write(etocChunk);
            }
        }finally{try(var walk=Files.walk(stage)){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(IOException ignored){}});}}
    }

    private static String sortKey(String s){StringBuilder b=new StringBuilder(s.length());for(char c:s.toCharArray())b.append(c=='_'?'~':Character.toLowerCase(c));return b.toString();}
    private static void putLe32At(byte[] b,int p,long v){b[p]=(byte)v;b[p+1]=(byte)(v>>>8);b[p+2]=(byte)(v>>>16);b[p+3]=(byte)(v>>>24);}

    private static UtfTable buildToc(List<Fi> fs){UtfTable t=new UtfTable();t.name="CpkTocInfo";t.columns.add(new UtfTable.Column("DirName",UtfTable.Type.STRING,UtfTable.Storage.DATA,""));t.columns.add(new UtfTable.Column("FileName",UtfTable.Type.STRING,UtfTable.Storage.DATA,""));t.columns.add(new UtfTable.Column("FileSize",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ExtractSize",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("FileOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ID",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("UserString",UtfTable.Type.STRING,UtfTable.Storage.CONSTANT,"<NULL>"));for(Fi f:fs){Map<String,Object> r=new LinkedHashMap<>();r.put("DirName",f.dir);r.put("FileName",f.name);r.put("FileSize",f.fileSize);r.put("ExtractSize",f.extractSize);r.put("FileOffset",f.offset);r.put("ID",f.id);t.rows.add(r);}return t;}

    private static UtfTable buildHeader(int files,int align,long contentOff,long contentSize,long tocSize,long etocOff,long packed,long extracted){UtfTable t=new UtfTable();t.name="CpkHeader";
        t.columns.add(new UtfTable.Column("UpdateDateTime",UtfTable.Type.ULONG,UtfTable.Storage.DATA,1L));t.columns.add(new UtfTable.Column("FileSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("ContentOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ContentSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TocOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TocSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TocCrc",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("EtocOffset",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("EtocSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("ItocOffset",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("ItocSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("ItocCrc",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("GtocOffset",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("GtocSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("GtocCrc",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("EnabledPackedSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("EnabledDataSize",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TotalDataSize",UtfTable.Type.ULONG,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Tocs",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Files",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("Groups",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("Attrs",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("TotalFiles",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Directories",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Updates",UtfTable.Type.UINT,UtfTable.Storage.CONSTANT,0L));t.columns.add(new UtfTable.Column("Version",UtfTable.Type.USHORT,UtfTable.Storage.DATA,7));t.columns.add(new UtfTable.Column("Revision",UtfTable.Type.USHORT,UtfTable.Storage.DATA,1));t.columns.add(new UtfTable.Column("Align",UtfTable.Type.USHORT,UtfTable.Storage.DATA,align));t.columns.add(new UtfTable.Column("Sorted",UtfTable.Type.USHORT,UtfTable.Storage.DATA,1));t.columns.add(new UtfTable.Column("EID",UtfTable.Type.USHORT,UtfTable.Storage.CONSTANT,0));t.columns.add(new UtfTable.Column("CpkMode",UtfTable.Type.UINT,UtfTable.Storage.DATA,1L));t.columns.add(new UtfTable.Column("Tvers",UtfTable.Type.STRING,UtfTable.Storage.DATA,"CPKMC2.30.07, DLL3.00.07"));t.columns.add(new UtfTable.Column("Comment",UtfTable.Type.STRING,UtfTable.Storage.CONSTANT,""));t.columns.add(new UtfTable.Column("Codec",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("DpkItoc",UtfTable.Type.UINT,UtfTable.Storage.DATA,0L));
        Map<String,Object> r=new LinkedHashMap<>();r.put("UpdateDateTime",1L);r.put("ContentOffset",contentOff);r.put("ContentSize",contentSize);r.put("TocOffset",0x800L);r.put("TocSize",tocSize);r.put("EtocOffset",etocOff);r.put("EtocSize",128L);r.put("EnabledPackedSize",packed+extracted);r.put("EnabledDataSize",packed+extracted);r.put("Files",(long)files);r.put("Groups",0L);r.put("Attrs",0L);r.put("Version",7);r.put("Revision",1);r.put("Align",align);r.put("Sorted",1);r.put("CpkMode",1L);r.put("Tvers","CPKMC2.30.07, DLL3.00.07");r.put("Codec",0L);r.put("DpkItoc",0L);t.rows.add(r);return t;}
    private static UtfTable buildEtoc(int files){UtfTable t=new UtfTable();t.name="CpkEtocInfo";t.columns.add(new UtfTable.Column("UpdateDateTime",UtfTable.Type.ULONG,UtfTable.Storage.DATA,0L));t.columns.add(new UtfTable.Column("LocalDir",UtfTable.Type.STRING,UtfTable.Storage.PER_ROW,""));for(int i=0;i<files;i++){Map<String,Object> r=new LinkedHashMap<>();r.put("UpdateDateTime",569143605520244480L);t.rows.add(r);}Map<String,Object> term=new LinkedHashMap<>();term.put("UpdateDateTime",0L);t.rows.add(term);return t;}
}
